//:cookieconsent
//:cookieconsent
require_once CAT_PATH.'/modules/cookieconsent/include.php';
return cc_include();
